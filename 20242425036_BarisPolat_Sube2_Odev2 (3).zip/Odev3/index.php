<?php
$sonuc = "";

if ($_POST) {
    $urun = $_POST["urun"];
    $fiyat = $_POST["fiyat"];
    $adet = $_POST["adet"];
    $kdv = $_POST["kdv"];
    $indirim = $_POST["indirim"];

    if ($urun == "" || $fiyat == "" || $adet == "") {
        $sonuc = "Boş alan bırakmayın!";
    } else {
        $ara = $fiyat * $adet;
        $kdvTutar = $ara * ($kdv / 100);

        if ($indirim == "IND10") $ara *= 0.9;
        if ($indirim == "IND20") $ara *= 0.8;

        $toplam = $ara + $kdvTutar;
        $sonuc = "Toplam: " . $toplam . " TL";
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<title>Sepet</title>
</head>
<body>

<form method="POST">
Ürün: <input name="urun"><br>
Fiyat: <input name="fiyat"><br>
Adet: <input name="adet"><br>

KDV:
<select name="kdv">
<option value="18">%18</option>
<option value="8">%8</option>
</select><br>

İndirim: <input name="indirim"><br>

<button>Hesapla</button>
</form>

<p><?php echo $sonuc; ?></p>

</body>
</html>

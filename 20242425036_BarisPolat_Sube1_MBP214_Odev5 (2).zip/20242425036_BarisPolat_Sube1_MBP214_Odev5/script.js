let currentFact = "";

async function getFact() {
    const container = document.getElementById("container");
    const errorDiv = document.getElementById("error");

    container.innerHTML = "";
    errorDiv.innerText = "";

    try {
        const response = await fetch("https://catfact.ninja/fact");
        const data = await response.json();

        currentFact = data.fact;

        renderFact(currentFact);

    } catch (error) {
        errorDiv.innerText = "API'den veri alınamadı!";
    }
}

function renderFact(fact) {
    const container = document.getElementById("container");
    container.innerHTML = "";

    const card = document.createElement("div");
    card.classList.add("card");

    card.innerHTML = `
        <h3>Kedi Bilgisi</h3>
        <p>${fact}</p>
    `;

    container.appendChild(card);
}

document.getElementById("search").addEventListener("input", function () {
    const value = this.value.toLowerCase();

    if (currentFact.toLowerCase().includes(value)) {
        renderFact(currentFact);
    } else {
        document.getElementById("container").innerHTML = "<p>Sonuç bulunamadı</p>";
    }
});

getFact();

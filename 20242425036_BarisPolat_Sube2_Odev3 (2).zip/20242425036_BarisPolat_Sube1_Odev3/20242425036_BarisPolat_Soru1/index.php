<?php
session_start();

$mesaj = "";
$tip = "";

if (isset($_SESSION["mesaj"])) {
    $mesaj = $_SESSION["mesaj"];
    $tip = $_SESSION["tip"];
    unset($_SESSION["mesaj"]);
    unset($_SESSION["tip"]);
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Soru 1 - Kullanıcı Girişi</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="kutu">
        <h1>Kullanıcı Girişi</h1>
        <p class="aciklama">Lütfen kullanıcı adı ve şifrenizi giriniz.</p>

        <?php if ($mesaj != "") { ?>
            <div class="mesaj <?php echo $tip; ?>">
                <?php echo $mesaj; ?>
            </div>
        <?php } ?>

        <form action="login_control.php" method="POST" accept-charset="UTF-8">
            <label>Kullanıcı Adı</label>
            <input type="text" name="kullanici_adi" placeholder="Kullanıcı adınızı giriniz" required>

            <label>Şifre</label>
            <input type="password" name="sifre" placeholder="Şifrenizi giriniz" required>

            <button type="submit">Giriş Yap</button>
        </form>

        <div class="bilgi">
            Örnek giriş bilgileri: <b>admin</b> / <b>1234</b>
        </div>
    </div>
</body>
</html>

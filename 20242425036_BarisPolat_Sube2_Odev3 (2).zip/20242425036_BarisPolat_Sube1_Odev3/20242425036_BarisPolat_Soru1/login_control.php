<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $kullanici_adi = $_POST["kullanici_adi"];
    $sifre = $_POST["sifre"];

    if ($kullanici_adi == "admin" && $sifre == "1234") {
        $_SESSION["mesaj"] = "Giriş başarılı. Hoş geldiniz admin!";
        $_SESSION["tip"] = "basarili";
    } else {
        $_SESSION["mesaj"] = "Kullanıcı adı veya şifre hatalı!";
        $_SESSION["tip"] = "hatali";
    }

    header("Location: index.php");
    exit();
} else {
    header("Location: index.php");
    exit();
}
?>

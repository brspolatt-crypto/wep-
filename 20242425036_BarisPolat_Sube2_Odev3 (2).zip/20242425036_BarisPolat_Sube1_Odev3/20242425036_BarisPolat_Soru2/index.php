<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Soru 2 - Alışveriş Sepeti Toplamı</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="kapsayici">
        <h1>Alışveriş Sepeti Toplamı</h1>
        <p>Ürün bilgilerini girerek KDV ve indirim hesaplamasını yapınız.</p>

        <form action="sepet_toplam.php" method="POST" accept-charset="UTF-8">
            <label>Ürün Adı</label>
            <input type="text" name="urun_adi" placeholder="Örn: Defter" required>

            <label>Ürün Fiyatı (TL)</label>
            <input type="number" step="0.01" min="0" name="fiyat" placeholder="Örn: 50" required>

            <label>Ürün Adedi</label>
            <input type="number" min="1" name="adet" placeholder="Örn: 2" required>

            <label>KDV Oranı (%)</label>
            <select name="kdv" required>
                <option value="20">%20</option>
                <option value="10">%10</option>
                <option value="1">%1</option>
            </select>

            <label>İndirim Kodu</label>
            <input type="text" name="indirim_kodu" placeholder="IND10 veya IND50">

            <button type="submit">Hesapla</button>
        </form>
    </div>
</body>
</html>

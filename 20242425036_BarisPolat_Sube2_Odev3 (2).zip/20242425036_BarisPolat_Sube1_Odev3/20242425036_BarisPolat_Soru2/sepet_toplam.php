<?php
function paraFormatla($deger) {
    return number_format($deger, 2, ",", ".");
}

$hata = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $urun_adi = trim($_POST["urun_adi"]);
    $fiyat = $_POST["fiyat"];
    $adet = $_POST["adet"];
    $kdv = $_POST["kdv"];
    $indirim_kodu = strtoupper(trim($_POST["indirim_kodu"]));

    if ($urun_adi == "" || $fiyat == "" || $adet == "" || $kdv == "") {
        $hata = "Lütfen zorunlu alanları boş bırakmayınız.";
    } elseif ($fiyat <= 0 || $adet <= 0) {
        $hata = "Fiyat ve adet bilgileri sıfırdan büyük olmalıdır.";
    }

    if ($hata == "") {
        $ara_toplam = $fiyat * $adet;
        $kdv_tutari = $ara_toplam * ($kdv / 100);

        $indirim_orani = 0;

        if ($indirim_kodu == "IND10") {
            $indirim_orani = 10;
        } elseif ($indirim_kodu == "IND50") {
            $indirim_orani = 50;
        }

        $indirim_tutari = $ara_toplam * ($indirim_orani / 100);
        $genel_toplam = $ara_toplam + $kdv_tutari - $indirim_tutari;
    }
} else {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Sepet Sonucu</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="kapsayici">
        <h1>Sepet Hesaplama Sonucu</h1>

        <?php if ($hata != "") { ?>
            <div class="hata"><?php echo $hata; ?></div>
            <a class="geri" href="index.php">Geri Dön</a>
        <?php } else { ?>
            <table>
                <tr>
                    <th>Bilgi</th>
                    <th>Sonuç</th>
                </tr>
                <tr>
                    <td>Ürün Adı</td>
                    <td><?php echo htmlspecialchars($urun_adi, ENT_QUOTES, "UTF-8"); ?></td>
                </tr>
                <tr>
                    <td>Birim Fiyat</td>
                    <td><?php echo paraFormatla($fiyat); ?> TL</td>
                </tr>
                <tr>
                    <td>Adet</td>
                    <td><?php echo $adet; ?></td>
                </tr>
                <tr>
                    <td>Ara Toplam</td>
                    <td><?php echo paraFormatla($ara_toplam); ?> TL</td>
                </tr>
                <tr>
                    <td>KDV Tutarı</td>
                    <td><?php echo paraFormatla($kdv_tutari); ?> TL</td>
                </tr>
                <tr>
                    <td>İndirim Kodu</td>
                    <td>
                        <?php
                        if ($indirim_orani > 0) {
                            echo $indirim_kodu . " uygulandı (%" . $indirim_orani . ")";
                        } else {
                            echo "Geçerli indirim kodu kullanılmadı";
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <td>İndirim Tutarı</td>
                    <td><?php echo paraFormatla($indirim_tutari); ?> TL</td>
                </tr>
                <tr class="toplam">
                    <td>Genel Toplam</td>
                    <td><?php echo paraFormatla($genel_toplam); ?> TL</td>
                </tr>
            </table>

            <a class="geri" href="index.php">Yeni Hesaplama Yap</a>
        <?php } ?>
    </div>
</body>
</html>
